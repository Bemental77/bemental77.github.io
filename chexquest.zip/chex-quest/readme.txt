Welcome to Chex� Quest Installation

 To install Chex� Quest, run install.exe on the CD-ROM. After installation, run the program by double clicking the icon "Launch Chex� Quest" that was created during installation. For Win 3.xx the icon is located in the file manager. For Win95 the icon is located in the Start menu.

 If you encounter problems running the game, you will need to exit to MS-DOS and run the program chex.exe located in the directory you chose during installation.

For best performance:
  Set the monitor to 256 colors and
  set the resolution to 640 x 480.